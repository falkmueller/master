﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AntFarm.Models
{
    public class StaffModel
    {
        public PointModel Point { get; set; }
        public int CostPerHoure { get; set; }
        public String[] Properties { get; set; }
    }
}
