﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AntFarm.Models
{
    public class OrderModel
    {
        public PointModel Point { get; set; }
        public int DurationInHours { get; set; }
        public int Duedate { get; set; }
        public int TardinessCostsPerHour { get; set; }
        public String[] ObligatoryStaffProperties { get; set; }
        public String[] OptionalStaffProperties { get; set; }
    }
}
