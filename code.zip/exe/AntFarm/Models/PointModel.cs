﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AntFarm.Models
{
    public class PointModel
    {
        public double Lat { get; set; }
        public double Lng { get; set; }

        protected PointModel()
        { }

        public PointModel(double lat, double lng)
        {
            Lat = lat;
            Lng = lng;
        }
    }
}
