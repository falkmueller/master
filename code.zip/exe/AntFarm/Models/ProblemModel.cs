﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AntFarm.Models
{
    public class ProblemModel
    {
        public List<StaffModel> Staffs { set; get; }

        public List<OrderModel> Orders { set; get; }

        public string Name { set; get; }

        public ProblemModel(List<StaffModel> staffs, List<OrderModel> orders) : this(staffs, orders, string.Empty)
        { }

        public ProblemModel(List<StaffModel> staffs, List<OrderModel> orders, string name)
        {
            Staffs = staffs;
            Orders = orders;
            Name = name;
        }

        protected ProblemModel() 
        { }

        public string GetUniqueName()
        {
            return GetUniqueName(Staffs.Count, Orders.Count, Name);
        }

        public static string GetUniqueName(int staffcount, int ordersCount, string name)
        {
            return $"Staff{staffcount}_Orders{ordersCount}_{name}";
        }
    }
}
