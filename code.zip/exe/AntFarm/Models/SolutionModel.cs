﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Abstraction;

namespace AntFarm.Models
{
    public class SolutionModel
    {
        public double Distance { protected set; get; }
        public double PropertyInaptitude { protected set; get; }
        public Int64 TardinessCosts { protected set; get; }
        public Int64 StuffOrderCosts { protected set; get; }
        public Int64 StaffTravelCosts { protected set; get; }
        public List<int>[] Result { protected set; get; }

        public SolutionModel(
            List<int>[] result, 
            double distance, 
            double propertyInaptitude,
            Int64 tardinessCosts,
            Int64 stuffOrderCosts,
            Int64 staffTravelCosts)
        {
            Result = result;
            Distance = distance;
            PropertyInaptitude = propertyInaptitude;
            TardinessCosts = tardinessCosts;
            StuffOrderCosts = stuffOrderCosts;
            StaffTravelCosts = staffTravelCosts;
        }

        public double GetTotalCosts()
        {
            //return Distance * 0.1 + TardinessCosts + StuffOrderCosts + StaffTravelCosts + Result.Length * PropertyPreference * 10;
            //return Distance * 0.1 + TardinessCosts * 0.1 + StuffOrderCosts + StaffTravelCosts + 1000000 * PropertyPreference;
            return Distance * 0.1 + TardinessCosts + StuffOrderCosts + StaffTravelCosts + 100 * PropertyInaptitude;
        }
    }
}
