﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AntFarm.Models
{
    public class RoutingResultModel
    {
        public float Distance;
        public float DurationInHours;
    }
}
