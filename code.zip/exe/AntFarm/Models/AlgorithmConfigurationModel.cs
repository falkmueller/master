﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AntFarm.Models
{
    public class AlgorithmConfigurationModel
    {
        public int K { get; set; } /* Anzahl Ameisen */
        public int NcMax { get; set; } /* Maximale Anzahl an iterationen */
        public float T0 { get; set; } /* InitialPheromon */
        public float P { get; set; } /* 0 <= p <= 1; Verdunstung*/
        public float DeltaT { get; set; } /* Update*/
        public float Alpha { get; set; } /* Einfluss Pheromon */
        public float Beta { get; set; } /* EInfluss Heuristik */ 
        public float Q { get; set; } /* 0 <= Q <= 1;  Weiche Proportions/Maximum regel */
        public float Qa { get; set; } /* 0 <= Qa <= 1;  Weiche Proportions/Maximum regel je Ameise oder je Entscheidung*/

        public float T { get; set; } = 0;

        public AlgorithmConfigurationModel(
            int k,
            int ncMax,
            float t0,
            float p,
            float deltaT,
            float alpha,
            float beta,
            float q,
            float qa
            )
        {
            K = k;
            NcMax = ncMax;
            T0 = t0;
            P = p;
            DeltaT = deltaT;
            Alpha = alpha;
            Beta = beta;
            Q = q;
            Qa = qa;
        }

        protected AlgorithmConfigurationModel()
        { }

        public string GetUniqueName()
        {
            var hash = Newtonsoft.Json.JsonConvert.SerializeObject(this);

            return $"K{K}_ncMax{NcMax}_{(int)(P * 10)}_{(int)(Alpha * 10)}_{hash.GetHashCode()}";
        }
    }
}
