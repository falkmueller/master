﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Abstraction;
using AntFarm.Models;
using AntFarm.Services;
using System.Linq;

namespace AntFarm.Algorithms
{
    public class Algorithm1Greedy : IAlgorithm
    {
        private List<StaffModel> _staffs;
        private List<OrderModel> _orders;
        private SolutionModel _bestSolution;
        private Random _random;
        private SolutionService _solutionService;

        public Algorithm1Greedy(SolutionService solutionService)
        {
            _orders = solutionService.Problem.Orders;
            _staffs = solutionService.Problem.Staffs;
            _solutionService = solutionService;
            _random = new Random();
        }

        public void Dispose()
        {
            _bestSolution = null;
        }

        public SolutionModel GetBestSolution()
        {
            return _bestSolution;
        }

        public IAlgorithm Run()
        {

            //for (var i = 0; i < _solutionService.AlgorithmConfiguration.K; i++)
            //{
                var solution = RunOneAnt();

                if (_bestSolution == null || _bestSolution.GetTotalCosts() > solution.GetTotalCosts())
                {
                    _bestSolution = solution;
                }
            //}

            return this;
        }

        private SolutionModel RunOneAnt() {
            var result = new List<int>[_staffs.Count];
            for (var i = 0; i < _staffs.Count; i++)
            {
                result[i] = new List<int>();
            }

            //bestellungen den Arbeitern zuordnen
            var orderids = Enumerable.Range(0, _orders.Count()).ToArray(); //.OrderBy((x) => _random.Next())
            //jede bestellung durchgehen
            foreach (var idxJob in orderids)
            {
                //an allen mitarbeitern testen
                var selectedEmployeeIdx = -1;
                float selectedEmployeeHeuristic = 0;

                for (var i = 0; i < _staffs.Count; i++)
                {
                    if (!_solutionService.canStaffProcessOrder(i, idxJob))
                    {
                        continue;
                    }

                    var currentHeuristic = _solutionService.Heuristic.getValue(_staffs[i], _orders[idxJob]);

                    if (selectedEmployeeIdx == -1 || currentHeuristic > selectedEmployeeHeuristic)
                    {
                        selectedEmployeeIdx = i;
                        selectedEmployeeHeuristic = currentHeuristic;
                    }
                }

                //den mit den geringsten kosten zuordnen
                result[selectedEmployeeIdx].Add(idxJob);
            }

            //bestellungen sortieren
            var sortedResult = new List<int>[_staffs.Count];

            for (var i = 0; i < _staffs.Count; i++)
            {
                sortedResult[i] = new List<int>();
            }

            for (var idxStaff = 0; idxStaff < _staffs.Count; idxStaff++)
            {

                var orders = result[idxStaff];
                var IdxLastOrder = -1;

                while (orders.Count > 0)
                {
                    var selectedOrder = -1;
                    var selectedHeuristic = 0f;

                    foreach (var idxJob in orders)
                    {
                        float heuristic;
                        if (IdxLastOrder == -1)
                        {
                            heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[idxJob]);
                        }
                        else
                        {
                            heuristic = _solutionService.Heuristic.getValue(_orders[idxJob], _orders[IdxLastOrder]);
                        }

                        if (heuristic > selectedHeuristic)
                        {
                            selectedOrder = idxJob;
                            selectedHeuristic = heuristic;
                        }
                    }

                    IdxLastOrder = selectedOrder;
                    sortedResult[idxStaff].Add(selectedOrder);
                    orders.Remove(selectedOrder);
                }
            }


            return _solutionService.buildSolution(sortedResult);
        }

        public List<object> GetPheromonMatrixs()
        {
            return null;
        }
    }
}
