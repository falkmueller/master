﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Abstraction;
using AntFarm.Models;
using AntFarm.Services;
using System.Linq;
using System.Numerics;

namespace AntFarm.Algorithms
{
    /*
     * 1 Matrix zur Job reihenfolge, 2 zur zuordnung von Arbeiter
     */
    class Algorithm4 : IAlgorithm
    {
        private List<StaffModel> _staffs;
        private List<OrderModel> _orders;
        private Random _random;
        private SolutionService _solutionService;
        private float[][] _pheromonesAssign; /*[Auftrag -> Mirarbeiter]*/
        private float[][] _pheromonesSorting; /*[Auftrag -> Reihenfolge]*/
        private SolutionModel _bestSolution;
        private AlgorithmConfigurationModel _conf;

        public Algorithm4(SolutionService solutionService)
        {
            _orders = solutionService.Problem.Orders;
            _staffs = solutionService.Problem.Staffs;
            _solutionService = solutionService;
            _conf = solutionService.AlgorithmConfiguration;
            _random = new Random();

            _pheromonesAssign = new float[this._orders.Count][];
            _pheromonesSorting = new float[this._orders.Count][];

            for (var j1 = 0; j1 < this._orders.Count; j1++)
            {
                _pheromonesAssign[j1] = new float[this._staffs.Count];

                _pheromonesSorting[j1] = new float[this._orders.Count];
                for (var j2 = 0; j2 < this._orders.Count; j2++)
                {
                    _pheromonesSorting[j1][j2] = _conf.T0;
                }

                for (var i1 = 0; i1 < this._staffs.Count; i1++)
                {
                    _pheromonesAssign[j1][i1] = _conf.T0;
                }
            }

            Console.WriteLine("Constructor is ready");
        }

        public SolutionModel GetBestSolution()
        {
            return this._bestSolution;
        }

        public IAlgorithm Run()
        {
            SolutionModel bestSolution = null;

            //run ants and compare
            for (var i = 0; i < _conf.K; i++)
            {
                var solution = runOneAnt();

                if (bestSolution == null || bestSolution?.GetTotalCosts() > solution.GetTotalCosts())
                {
                    bestSolution = solution;
                }
            }

            //vaporisation
            vaporisation(bestSolution);

            //update booth 
            update(bestSolution);

            //save result
            if (_bestSolution == null || _bestSolution?.GetTotalCosts() > bestSolution.GetTotalCosts())
            {
                _bestSolution = bestSolution;
            }

            return this;
        }

        private void vaporisation(SolutionModel solution)
        {
            for (var j1 = 0; j1 < this._orders.Count; j1++)
            {
                for (var j2 = 0; j2 < this._orders.Count; j2++)
                {
                    _pheromonesSorting[j1][j2] *= (1 - _conf.P);
                }

                for (var i1 = 0; i1 < this._staffs.Count; i1++)
                {
                    _pheromonesAssign[j1][i1] *= (1 - _conf.P);
                }
            }
        }

        private void update(SolutionModel solution)
        {
            var deltaT = _conf.P * _conf.DeltaT;
            for (var employeeIdx = 0; employeeIdx < this._staffs.Count; employeeIdx++)
            {
                var position = 0;
                foreach (var idxOrder in solution.Result[employeeIdx])
                {
                    _pheromonesAssign[idxOrder][employeeIdx] += deltaT;
                    _pheromonesSorting[position][idxOrder] += deltaT;
                    position++;
                }
            }
        }

        private SolutionModel runOneAnt()
        {
            //bestimme job reihenfolge
            var sortedJobs = getsortedJob();

            //Reihenfolge in der Mitarbeiter Auftrag abarbeiten bestimmen
            return getEmployeeJobAssignment(sortedJobs);

        }

        /*Reihenfolge in der Mitarbeiter Auftrag Abarbeiten*/
        private SolutionModel getEmployeeJobAssignment(int[] sortedJobs)
        {
            var result = new List<int>[_staffs.Count];
           
            for (var i = 0; i < _staffs.Count; i++)
            {
                result[i] = new List<int>();
            }

            bool useMaxRule;

            foreach (var orderIdx in sortedJobs)
            {
                useMaxRule = (float)_random.NextDouble() <= _conf.Q;
                var selectedIdxStaff = 0;

                if (useMaxRule)
                {
                    /*MAX(τijα * ηijβ)*/
                    float maxValue = 0;

                    for (var idxStaff = 0; idxStaff < _staffs.Count; idxStaff++)
                    {
                        if (!_solutionService.canStaffProcessOrder(idxStaff, orderIdx))
                        {
                            continue;
                        }

                        float heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[orderIdx]);
                        var pheromon = _pheromonesAssign[orderIdx][idxStaff];
                        var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));

                        if (value > maxValue)
                        {
                            maxValue = value;
                            selectedIdxStaff = idxStaff;
                        }
                    }
                }
                else
                {
                    float total = 0;

                    for (var idxStaff = 0; idxStaff < _staffs.Count; idxStaff++)
                    {
                        if (!_solutionService.canStaffProcessOrder(idxStaff, orderIdx))
                        {
                            continue;
                        }

                        float heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[orderIdx]);
                        var pheromon = _pheromonesAssign[orderIdx][idxStaff];
                        var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));
                        total += value;
                    }

                    var randomValue = _random.NextDouble() * total;
                    double currentValue = 0;

                    for (var idxStaff = 0; idxStaff < _staffs.Count; idxStaff++)
                    {
                        if (!_solutionService.canStaffProcessOrder(idxStaff, orderIdx))
                        {
                            continue;
                        }

                        float heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[orderIdx]);
                        var pheromon = _pheromonesAssign[orderIdx][idxStaff];
                        var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));
                        currentValue += value;
                        if (randomValue <= currentValue)
                        {
                            selectedIdxStaff = idxStaff;
                            break;
                        }
                    }
                }

                result[selectedIdxStaff].Add(orderIdx);
            }

            return _solutionService.buildSolution(result);
        }

        private int[] getsortedJob()
        {
            var joborder = new int[_orders.Count];
            var openOrders = Enumerable.Range(0, _orders.Count).ToList();
            var countJobs = _orders.Count();
            var IdxLastOrder = countJobs;

            bool useMaxRule;

            for (var idxPosition = 0; idxPosition < _orders.Count; idxPosition++)
            {
                useMaxRule = (float)_random.NextDouble() <= _conf.Q;

                if (useMaxRule)
                {
                    /*MAX(τijα * ηijβ)*/
                    float maxValue = 0;
                    int maxValueIdxJob = 0;

                    foreach (var orderIdx in openOrders)
                    {
                        float heuristic = IdxLastOrder == countJobs ? 0 : _solutionService.Heuristic.getValue(_orders[orderIdx], _orders[IdxLastOrder]);
                        var pheromon = _pheromonesSorting[idxPosition][orderIdx];
                        var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));

                        if (value > maxValue)
                        {
                            maxValue = value;
                            maxValueIdxJob = orderIdx;
                        }
                    }

                    joborder[idxPosition] = maxValueIdxJob;
                    openOrders.Remove(maxValueIdxJob);
                    IdxLastOrder = maxValueIdxJob;
                }
                else {
                    float total = 0;

                    foreach (var orderIdx in openOrders)
                    {
                        float heuristic = IdxLastOrder == countJobs ? 0 : _solutionService.Heuristic.getValue(_orders[orderIdx], _orders[IdxLastOrder]);
                        var pheromon = _pheromonesSorting[idxPosition][orderIdx];
                        var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));
                        total += value;
                    }

                    var randomValue = _random.NextDouble() * total;
                    double currentValue = 0;

                    foreach (var orderIdx in openOrders)
                    {
                        float heuristic = IdxLastOrder == countJobs ? 0 : _solutionService.Heuristic.getValue(_orders[orderIdx], _orders[IdxLastOrder]);
                        var pheromon = _pheromonesSorting[idxPosition][orderIdx];
                        var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));
                        currentValue += value;
                        if (randomValue <= currentValue)
                        {
                            joborder[idxPosition] = orderIdx;
                            openOrders.Remove(orderIdx);
                            IdxLastOrder = orderIdx;
                            break;
                        }
                    }
                }
            }

            return joborder;
        }

        public void Dispose()
        {
            _pheromonesAssign = null;
            _pheromonesSorting = null;
            _bestSolution = null;
        }

        public List<object> GetPheromonMatrixs()
        {
            return new List<object>
            { 
                _pheromonesAssign,
                _pheromonesSorting
            };
        }
    }
}
