﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Abstraction;
using AntFarm.Models;
using AntFarm.Services;
using System.Linq;
using System.Numerics;

namespace AntFarm.Algorithms
{
    /*
     * 3 Mimensions Matrix [Mirarbeiter -> Auftrag -> Reihenfolge]
     */
    public class Algorithm3 : IAlgorithm
    {
        private List<StaffModel> _staffs;
        private List<OrderModel> _orders;
        private Random _random;
        private SolutionService _solutionService;
        private float[][][] _pheromones; /*[Mirarbeiter -> Auftrag -> Reihenfolge]*/
        private SolutionModel _bestSolution;
        private AlgorithmConfigurationModel _conf;

        public Algorithm3(SolutionService solutionService)
        {
            _orders = solutionService.Problem.Orders;
            _staffs = solutionService.Problem.Staffs;
            _solutionService = solutionService;
            _conf = _solutionService.AlgorithmConfiguration;
            _random = new Random();

            _pheromones = new float[this._staffs.Count][][];

            for (var i1 = 0; i1 < this._staffs.Count; i1++)
            {
                _pheromones[i1] = new float[this._orders.Count][];
                for (var j1 = 0; j1 < this._orders.Count; j1++)
                {
                    _pheromones[i1][j1] = new float[this._orders.Count];
                    for (var j2 = 0; j2 < this._orders.Count; j2++)
                    {
                        _pheromones[i1][j1][j2] = _solutionService.AlgorithmConfiguration.T0;
                    }

                }
            }

            Console.WriteLine("Constructor is ready");

        }

        public IAlgorithm Run()
        {
            InternSolutionModel bestSolution = null;
            
            //run ants and compare
            for (var i = 0; i < _solutionService.AlgorithmConfiguration.K; i++)
            {
                var solution = runOneAnt();

                if (bestSolution == null || bestSolution?.solution.GetTotalCosts() > solution.solution.GetTotalCosts())
                {
                    bestSolution = solution;
                }
            }

            //vaporisation
            foreach (var idxStaff in Enumerable.Range(0, _staffs.Count))
            {
                foreach (var idxOrder in Enumerable.Range(0, _orders.Count))
                {
                    foreach (var idxSort in Enumerable.Range(0, _orders.Count))
                    {
                        _pheromones[idxStaff][idxOrder][idxSort] *= (1 - _conf.P);
                    }
                }
            }

            //best ant update
            var orderIdx = 0;
            foreach (var node in bestSolution.NodeList)
            {
                _pheromones[node.IdxStaff][node.IdxOrder][orderIdx++] += _conf.DeltaT;
            }

            if (_bestSolution == null || _bestSolution?.GetTotalCosts() > bestSolution.solution.GetTotalCosts())
            {
                _bestSolution = bestSolution.solution;
            }

            return this;
        }

        private InternSolutionModel runOneAnt()
        {
            var result = new List<int>[_staffs.Count];
            var nodeList = new List<NodeModel>();
            bool useMaxRule;

            var openOrdersIdxs = Enumerable.Range(0, _orders.Count).ToList();

            for (var i = 0; i < _staffs.Count; i++)
            {
                result[i] = new List<int>();
            }

            var sortIdx = 0;
            while (openOrdersIdxs.Count > 0)
            {
                useMaxRule = (float)_random.NextDouble() <= _conf.Q;

                /*betrachte alle kanten von aktuellen Knoten zu den Knoten der noch offnen Orders*/

                int idxStaff;
                int idxOrder = 0;

                if (useMaxRule)
                {
                    /*MAX(τijα * ηijβ)*/
                    float maxValue = 0;
                    int maxValueIdxStaff = 0;
                    int maxValueIdxOrder = 0;

                    for (idxStaff = 0; idxStaff < this._staffs.Count; idxStaff++)
                    {
                        foreach (var idxOpenOrder in openOrdersIdxs)
                        {
                            if (!_solutionService.canStaffProcessOrder(idxStaff, idxOpenOrder))
                            {
                                continue;
                            }
                            var heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[idxOpenOrder]);
                            var pheromon = _pheromones[idxStaff][idxOpenOrder][sortIdx];
                            var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));
                            if (value > maxValue)
                            {
                                maxValue = value;
                                maxValueIdxStaff = idxStaff;
                                maxValueIdxOrder = idxOpenOrder;
                            }
                        }
                    }

                    idxStaff = maxValueIdxStaff;
                    idxOrder = maxValueIdxOrder;
                }
                else
                {
                    /*Auswahl gewichteter Zufall BEGIN*/
                    double total = 0;

                    for (idxStaff = 0; idxStaff < this._staffs.Count; idxStaff++)
                    {
                        foreach (var idxOpenOrder in openOrdersIdxs)
                        {
                            if (!_solutionService.canStaffProcessOrder(idxStaff, idxOpenOrder))
                            {
                                continue;
                            }

                            var heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[idxOpenOrder]);
                            var pheromon = _pheromones[idxStaff][idxOpenOrder][sortIdx];
                            var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));
                            total += value;
                        }
                    }

                    var randomValue = _random.NextDouble() * total;
                    double currentValue = 0;

                    for (idxStaff = 0; idxStaff < this._staffs.Count; idxStaff++)
                    {
                        foreach (var idxOpenOrder in openOrdersIdxs)
                        {
                            if (!_solutionService.canStaffProcessOrder(idxStaff, idxOpenOrder))
                            {
                                continue;
                            }

                            var heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[idxOpenOrder]);
                            var pheromon = _pheromones[idxStaff][idxOpenOrder][sortIdx];
                            var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));
                            currentValue += value;
                            if (randomValue <= currentValue)
                            {
                                idxOrder = idxOpenOrder;
                                break;
                            }
                        }

                        if (randomValue <= currentValue)
                        {
                            break;
                        }
                    }
                    /*Auswahl gewichteter Zufall END*/
                }

                var newNode = new NodeModel(idxOrder, idxStaff);

                result[newNode.IdxStaff].Add(newNode.IdxOrder);

                //füge knoten in Lösung ein
                nodeList.Add(newNode);

                //entferne Auftrag aus offenen Aufträgen
                openOrdersIdxs.Remove(idxOrder);
                sortIdx++;
            }

            return new InternSolutionModel
            { 
                NodeList = nodeList,
                solution = _solutionService.buildSolution(result)
            };
        }

        public SolutionModel GetBestSolution()
        {
            return this._bestSolution;
        }

        public void Dispose()
        {
            _pheromones = null;
            _bestSolution = null;
        }

        private class InternSolutionModel
        {
            public List<NodeModel> NodeList = new List<NodeModel>();
            public SolutionModel solution;
        }

        class NodeModel
        {
            public int IdxOrder;
            public int IdxStaff;

            public NodeModel(int idxOrder, int idxStaff)
            {
                IdxOrder = idxOrder;
                IdxStaff = idxStaff;
            }
        }

        public List<object> GetPheromonMatrixs()
        {
            return new List<object>
            {
                _pheromones
            };
        }
    }
}
