﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Abstraction;
using AntFarm.Models;
using AntFarm.Services;
using System.Linq;

/**
 * https://master.falk-m.de/setup/versuche
 * 4 D Matrix für Pheromone des Graphen den Ameisen ablaufen 
 * [i1, j1, i2, j2]
*/
namespace AntFarm.Algorithms
{
    class Algorithm2Simple : IAlgorithm
    {
        private List<StaffModel> _staffs;
        private List<OrderModel> _orders;
        private int _antcount = 10;
        private Random _random;
        private SolutionService _solutionService;
        private float _vaposisation = 0.4F; /*[0,1]*/
        private float _antUpdatePheromon = 0.9F;
        private float[,][,] _pheromones;
        private SolutionModel _bestSolution;

        public Algorithm2Simple(SolutionService solutionService)
        {
            _orders = solutionService.Problem.Orders;
            _staffs = solutionService.Problem.Staffs;
            _solutionService = solutionService;
            _random = new Random();

            _pheromones = new float[this._staffs.Count + 1, this._orders.Count + 1][,];

            for (var i1 = 0; i1 <= this._staffs.Count; i1++)
            {
                for (var j1 = 0; j1 <= this._orders.Count; j1++)
                {
                    _pheromones[i1,j1] = new float[this._staffs.Count + 1, this._orders.Count + 1];
                    //for (var i2 = 0; i2 <= this._staffs.Count; i2++)
                    //{
                    //    for (var j2 = 0; j2 <= this._orders.Count; j2++)
                    //    {
                    //        _pheromones[i1,j1][i2,j2] = _initalPheromon;
                    //    }
                    //}
                }
            }

            Console.WriteLine("Algorithmus 1: Contruct ready");
        }

        public IAlgorithm Run()
        {
            InternSolutionModel bestSolution = null;

            //run ants and compare
            for (var i = 0; i < _antcount; i++)
            {
                var solution = runOneAnt();

                if (bestSolution == null || bestSolution?.solution.GetTotalCosts() > solution.solution.GetTotalCosts())
                {
                    bestSolution = solution;
                }
            }

            //vaporisation
            for (var i1 = 0; i1 <= this._staffs.Count; i1++)
            {
                for (var j1 = 0; j1 <= this._orders.Count; j1++)
                {
                    for (var i2 = 0; i2 <= this._staffs.Count; i2++)
                    {
                       for (var j2 = 0; j2 <= this._orders.Count; j2++)
                        {
                            _pheromones[i1,j1][i2,j2] *= (1 - this._vaposisation);
                        }
                    }
                }
            }

            //best ant update
            var currentNode = new NodeModel(_orders.Count, _staffs.Count);
            foreach (var node in bestSolution.NodeList)
            {
                _pheromones[currentNode.IdxStaff,currentNode.IdxOrder][node.IdxStaff,node.IdxOrder] += this._vaposisation * _antUpdatePheromon;
                currentNode = node;
            }

            if (_bestSolution == null || _bestSolution?.GetTotalCosts() > bestSolution.solution.GetTotalCosts())
            {
                _bestSolution = bestSolution.solution;
            }

            return this;
        }

        private InternSolutionModel runOneAnt()
        {
            var result = new List<int>[_staffs.Count];
            var nodeList = new List<NodeModel>();

            var openOrdersIdxs = Enumerable.Range(0, _orders.Count).ToList();
            var currentNode = new NodeModel(_orders.Count, _staffs.Count);

            for (var i = 0; i < _staffs.Count; i++)
            {
                result[i] = new List<int>();
            }

            while (openOrdersIdxs.Count > 0)
            {
                /*betrachte alle kanten von aktuellen Knoten zu den Knoten der noch offnen Orders*/

                /*Auswahl gewichteter Zufall BEGIN*/
                double total = 0;
                int idxStaff;
                int idxOrder = 0;
                var openOrdersIdx = 0;

                for (idxStaff = 0; idxStaff < this._staffs.Count; idxStaff++)
                {
                    foreach (var idxOpenOrder in openOrdersIdxs)
                    {
                        total += _pheromones[currentNode.IdxStaff,currentNode.IdxOrder][idxStaff,idxOpenOrder];
                    }
                }

                var randomValue = _random.NextDouble() * total;
                double currentValue = 0;
                for (idxStaff = 0; idxStaff < this._staffs.Count; idxStaff++)
                {
                    foreach (var idxOpenOrder in openOrdersIdxs)
                    {
                        currentValue += _pheromones[currentNode.IdxStaff,currentNode.IdxOrder][idxStaff,idxOpenOrder];
                        if (randomValue <= currentValue)
                        {
                            idxOrder = idxOpenOrder;
                            break;
                        }
                    }

                    if (randomValue <= currentValue)
                    {
                        break;
                    }
                }
                /*Auswahl gewichteter Zufall END*/

                var newNode = new NodeModel(idxOrder, idxStaff);

                result[newNode.IdxStaff].Add(newNode.IdxOrder);

                //füge knoten in Lösung ein
                nodeList.Add(newNode);
                currentNode = newNode;

                //entferne Auftrag auf offenen Aufträgen
                openOrdersIdxs.RemoveAt(openOrdersIdx);
            }

            return new InternSolutionModel
            {
                NodeList = nodeList,
                solution = _solutionService.buildSolution(result)
            };
        }

        public SolutionModel GetBestSolution()
        {
            return this._bestSolution;
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        private class InternSolutionModel
        {
            public List<NodeModel> NodeList = new List<NodeModel>();
            public SolutionModel solution;
        }

        class NodeModel
        {
            public int IdxOrder;
            public int IdxStaff;

            public NodeModel(int idxOrder, int idxStaff)
            {
                IdxOrder = idxOrder;
                IdxStaff = idxStaff;
            }
        }

        public List<object> GetPheromonMatrixs()
        {
            return null;
        }
    }
}
