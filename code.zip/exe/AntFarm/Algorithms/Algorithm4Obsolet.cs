﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Abstraction;
using AntFarm.Models;
using AntFarm.Services;
using System.Linq;

namespace AntFarm.Algorithms
{
    /**
     * - Graph repräsentiert nur, dass Mitarbeiter i den Job j bearbeitet, ohne reihenfolge
     * - einfache Matrix mit Mirarbeiter auf der einen Axe, Jobs auf der anderen Axe
     * - ein zweiter Matrix übernimmt dann die reihenfolge in der der mitarbeiter diese abfährt
     */
    class Algorithm4Obsolet : IAlgorithm
    {
        private List<StaffModel> _staffs;
        private List<OrderModel> _orders;
        private int _antcount = 10;
        private Random _random;
        private SolutionService _solutionService;
        private float _initalPheromon = 0.1F;
        private float _vaposisation = 0.6F; /*[0,1]*/
        private float _antUpdatePheromon = 0.9F;
        private float[][] _pheromonesAssign; /*[Auftrag -> Mirarbeiter]*/
        private float[][] _pheromonesSorting; /*[Auftrag -> Reihenfolge]*/
        private SolutionModel _bestSolution;

        public Algorithm4Obsolet(SolutionService solutionService)
        {
            _orders = solutionService.Problem.Orders;
            _staffs = solutionService.Problem.Staffs;
            _solutionService = solutionService;
            _random = new Random();

            _pheromonesAssign = new float[this._orders.Count][];
            _pheromonesSorting = new float[this._orders.Count][];

            for (var j1 = 0; j1 < this._orders.Count; j1++)
            {
                _pheromonesAssign[j1] = new float[this._staffs.Count];
                
                _pheromonesSorting[j1] = new float[this._orders.Count];
                for (var j2 = 0; j2 < this._orders.Count; j2++)
                {
                    _pheromonesSorting[j1][j2] = _initalPheromon;
                }

                for (var i1 = 0; i1 < this._staffs .Count; i1++)
                {
                    _pheromonesAssign[j1][i1] = _initalPheromon;
                }
            }

            Console.WriteLine("Constructor is ready");
        }

        public SolutionModel GetBestSolution()
        {
            return this._bestSolution;
        }

        public IAlgorithm Run()
        {
            SolutionModel bestSolution = null;

            //run ants and compare
            for (var i = 0; i < _antcount; i++)
            {
                var solution = runOneAnt();

                if (bestSolution == null || bestSolution?.GetTotalCosts() > solution.GetTotalCosts())
                {
                    bestSolution = solution;
                }
            }

            //vaporisation
            vaporisation(bestSolution);

            //update booth 
            update(bestSolution);

            //save result
            if (_bestSolution == null || _bestSolution?.GetTotalCosts() > bestSolution.GetTotalCosts())
            {
                _bestSolution = bestSolution;
            }

            return this;
        }

        private void vaporisation(SolutionModel solution)
        {
            for (var j1 = 0; j1 < this._orders.Count; j1++)
            {
                for (var j2 = 0; j2 < this._orders.Count; j2++)
                {
                    _pheromonesSorting[j1][j2] *= (1 - this._vaposisation);
                }

                for (var i1 = 0; i1 < this._staffs.Count; i1++)
                {
                    _pheromonesAssign[j1][i1] *= (1 - this._vaposisation);
                }
            }
        }

        private void update(SolutionModel solution)
        {
            for (var employeeIdx = 0; employeeIdx < this._staffs.Count; employeeIdx++)
            {
                var position = 0;
                foreach (var idxOrder in solution.Result[employeeIdx])
                {
                    _pheromonesAssign[idxOrder][employeeIdx] += _antUpdatePheromon;
                    _pheromonesSorting[position][idxOrder] += _antUpdatePheromon;
                    position++;
                }
            }
        }

        private SolutionModel runOneAnt()
        {
            //bestimme job -> Mitarbeiter zuordnung
            var employeeJobAssignment = getEmployeeJobAssignment();

            //Reihenfolge in der Mitarbeiter Auftrag abarbeiten bestimmen
            return sortEmployeeJobAssignment(employeeJobAssignment);

        }

        /*Reihenfolge in der Mitarbeiter Auftrag Abarbeiten*/
        private SolutionModel sortEmployeeJobAssignment(List<int>[] employeeJobAssignment)
        {
            var result = new List<int>[_staffs.Count];

            for (var i = 0; i < _staffs.Count; i++)
            {
                result[i] = new List<int>();
            }

            var position = 0;
            for (var idxStaff = 0; idxStaff < _staffs.Count; idxStaff++)
            {
                var orders = employeeJobAssignment[idxStaff];
                while (orders.Count > 0)
                {
                    float total = 0;
                    foreach (var orderIdx in orders)
                    {
                        total += _pheromonesSorting[position][orderIdx];
                    }

                    var randomValue = _random.NextDouble() * total;
                    double currentValue = 0;
                    var selectedOrderIdx = 0;

                    foreach (var orderIdx in orders)
                    {
                        currentValue += _pheromonesSorting[position][orderIdx];
                        if (randomValue <= currentValue)
                        {
                            selectedOrderIdx = orderIdx;
                            break;
                        }
                    }

                    orders.Remove(selectedOrderIdx);
                    result[idxStaff].Add(selectedOrderIdx);
                    position++;
                }
            }

            return _solutionService.buildSolution(result);
        }

        /*welcher Mitarbeiter bearbeitet welchen Job*/
        private List<int>[] getEmployeeJobAssignment()
        {
            var employeeJobAssignment = new List<int>[_staffs.Count];
            for (var i = 0; i < _staffs.Count; i++)
            {
                employeeJobAssignment[i] = new List<int>();
            }

            for (var idxJob = 0; idxJob < _orders.Count; idxJob++)
            {
                float total = 0;

                for (var i = 0; i < _staffs.Count; i++)
                {
                    if (!_solutionService.canStaffProcessOrder(i, idxJob))
                    {
                        continue;
                    }
                    total += _pheromonesAssign[idxJob][i];
                }

                var randomValue = _random.NextDouble() * total;
                double currentValue = 0;

                for (var i = 0; i < _staffs.Count; i++)
                {
                    if (!_solutionService.canStaffProcessOrder(i, idxJob))
                    {
                        continue;
                    }
                    currentValue += _pheromonesAssign[idxJob][i];
                    if (randomValue <= currentValue)
                    {
                        employeeJobAssignment[i].Add(idxJob);
                        break;
                    }
                }
            }

            return employeeJobAssignment;
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public List<object> GetPheromonMatrixs()
        {
            return null;
        }
    }
}
