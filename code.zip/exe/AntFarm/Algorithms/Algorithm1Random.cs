﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Abstraction;
using AntFarm.Models;
using AntFarm.Services;
using System.Linq;

namespace AntFarm.Algorithms
{
    /**
     * Einfacher Algorightmus
     * Keine pheromone oder Heuristik
     * Rein zufällige Wahl
     * Kalender der Mitarbeiter wird als Komplett leer angenommen
     */
    class Algorithm1Random : IAlgorithm
    {
        private List<StaffModel> _staffs;
        private List<OrderModel> _orders;
        private int _antcount = 100;
        private SolutionModel _bestSolution;
        private Random _random;
        private SolutionService _solutionService;

        public Algorithm1Random(SolutionService solutionService)
        {
            _orders = solutionService.Problem.Orders;
            _staffs = solutionService.Problem.Staffs;
            _solutionService = solutionService;
            _random = new Random();
        }

        public SolutionModel GetBestSolution()
        {
            return _bestSolution;
        }

        public IAlgorithm Run()
        {
            SolutionModel bestSolution = null;

            for (var i = 0; i < _antcount; i++)
            {
                var solution = createSolutionFromNodeList(runOneAnt());

                if (bestSolution == null || bestSolution?.GetTotalCosts() > solution.GetTotalCosts())
                {
                    bestSolution = solution;
                }
            }

            if (_bestSolution == null || _bestSolution.GetTotalCosts() > bestSolution.GetTotalCosts())
            {
                _bestSolution = bestSolution;
            }

            return this;
        }

        private List<NodeModel> runOneAnt()
        {
            var nodeList = new List<NodeModel>();

            var openOrdersIdxs = Enumerable.Range(0, _orders.Count).ToList();
            var maxLoop = _orders.Count * _orders.Count;

            while (openOrdersIdxs.Count > 0)
            {
                if (maxLoop-- < 0)
                {
                    throw new Exception("Ant need to long");
                }
                
                //wähle Zufällig Mitarbeiter 
                var idxStaff = _random.Next(0, _staffs.Count - 1);

                //Wähle zufällig nicht abgearbeiteten Auftrag
                var openOrdersIdx = _random.Next(0, openOrdersIdxs.Count - 1);
                var idxOrder = openOrdersIdxs[openOrdersIdx];

                //wenn mitarbeiter Auftrag nicht bearbeiten kann -> continue
                if (!_solutionService.canStaffProcessOrder(idxStaff, idxOrder))
                {
                    continue;
                }

                //füge knoten in Lösung ein
                nodeList.Add(new NodeModel(idxOrder, idxStaff));

                //entferne Auftrag auf offenen Aufträgen
                openOrdersIdxs.RemoveAt(openOrdersIdx);
            }

            return nodeList;
        }

        private SolutionModel createSolutionFromNodeList(List<NodeModel> nodeList)
        {
            var result = new List<int>[_staffs.Count];

            for (var i = 0; i < _staffs.Count; i++)
            {
                result[i] = new List<int>();
            }

            foreach (var node in nodeList)
            {
                result[node.IdxStaff].Add(node.IdxOrder);
            }

            return _solutionService.buildSolution(result);
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        class NodeModel
        {
            public int IdxOrder;
            public int IdxStaff;

            public NodeModel(int idxOrder, int idxStaff)
            {
                IdxOrder = idxOrder;
                IdxStaff = idxStaff;
            }
        }

        public List<object> GetPheromonMatrixs()
        {
            return null;
        }
    }
}
