﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Abstraction;
using AntFarm.Models;
using AntFarm.Services;
using System.Linq;
using System.Numerics;

namespace AntFarm.Algorithms
{
    /**
     * - Implementierung von Q16
     * - Graph repräsentiert nur, dass Mitarbeiter i den Job j bearbeitet, ohne reihenfolge
     * - zweite Matrix gibt an, dass je mitarbeiter Job i nach job j bearbeitet werden soll
     */
    class Algorithm6 : IAlgorithm
    {
        private List<StaffModel> _staffs;
        private List<OrderModel> _orders;
        private Random _random;
        private SolutionService _solutionService;
        private float[][] _pheromonesAssign; /*[Auftrag -> Mirarbeiter]*/
        private float[][] _pheromonesSorting; /*[Auftrag -> Reihenfolge]*/
        private SolutionModel _bestSolution;
        private AlgorithmConfigurationModel _conf;

        public Algorithm6(SolutionService solutionService)
        {
            _orders = solutionService.Problem.Orders;
            _staffs = solutionService.Problem.Staffs;
            _solutionService = solutionService;
            _conf = solutionService.AlgorithmConfiguration;
            _random = new Random();

            _pheromonesAssign = new float[this._staffs.Count][];
            _pheromonesSorting = new float[this._orders.Count][];

            for (var i = 0; i < this._staffs.Count; i++)
            {

                _pheromonesAssign[i] = new float[this._orders.Count];

                for (var j = 0; j < this._orders.Count; j++)
                {
                    _pheromonesAssign[i][j] = _conf.T0;
                }
            }

            for (var j = 0; j < this._orders.Count; j++)
            {
                _pheromonesSorting[j] = new float[this._orders.Count + 1];


                for (var j2 = 0; j2 <= this._orders.Count; j2++)
                {
                    _pheromonesSorting[j][j2] = _conf.T0;
                }
            }

            Console.WriteLine("Constructor is ready");
        }

        public SolutionModel GetBestSolution()
        {
            return this._bestSolution;
        }

        public IAlgorithm Run()
        {
            SolutionModel bestSolution = null;

            //run ants and compare
            for (var i = 0; i < _conf.K; i++)
            {
                var solution = runOneAnt();

                if (bestSolution == null || bestSolution?.GetTotalCosts() > solution.GetTotalCosts())
                {
                    bestSolution = solution;
                }
            }

            //save result
            if (_bestSolution == null || _bestSolution?.GetTotalCosts() > bestSolution.GetTotalCosts())
            {
                _bestSolution = bestSolution;
            }

            if (_conf.T > 0)
            {
                _bestSolution = LocalSearch(_bestSolution);
            }

            //vaporisation
            vaporisation(_bestSolution);

            //update booth 
            update(_bestSolution);

            return this;
        }

        private SolutionModel LocalSearch(SolutionModel initSolution) {

            var bestCosts = initSolution.GetTotalCosts();
            var bestResult = initSolution.Result;

            //Ahmadizar
            for (var idxStaff = 0; idxStaff < initSolution.Result.Length; idxStaff++)
            {
                foreach (var idxOrder in initSolution.Result[idxStaff])
                {
                    if (_random.NextDouble() > _conf.T) { continue; }
                    Console.WriteLine("Start local search");
                    var newResult = Newtonsoft.Json.JsonConvert.DeserializeObject<List<int>[]>(Newtonsoft.Json.JsonConvert.SerializeObject(bestResult));

                    newResult[idxStaff].Remove(idxOrder);

                    for (var idxStaffNew = 0; idxStaffNew < newResult.Length; idxStaffNew++) {
                        var l = newResult[idxStaffNew].Count;
                        SolutionModel newSolution;

                        for (var i = 0; i < l; i++) {
                            newResult[idxStaffNew].Insert(i, idxOrder);

                            newSolution = _solutionService.buildSolution(newResult);
                            if (newSolution.GetTotalCosts() < bestCosts) {
                                bestCosts = newSolution.GetTotalCosts();
                                bestResult = Newtonsoft.Json.JsonConvert.DeserializeObject<List<int>[]>(Newtonsoft.Json.JsonConvert.SerializeObject(newResult));
                                Console.WriteLine("find better result {0}", bestCosts);
                            }

                            newResult[idxStaffNew].Remove(idxOrder);
                        }

                        //append test
                        newResult[idxStaffNew].Append(idxOrder);
                        newSolution = _solutionService.buildSolution(newResult);
                        if (newSolution.GetTotalCosts() < bestCosts)
                        {
                            bestCosts = newSolution.GetTotalCosts();
                            bestResult = Newtonsoft.Json.JsonConvert.DeserializeObject<List<int>[]>(Newtonsoft.Json.JsonConvert.SerializeObject(newResult));
                            Console.WriteLine("find better result {0}", bestCosts);
                        }

                        newResult[idxStaffNew].Remove(idxOrder);
                    }
                    Console.WriteLine("End local search");
                }
            }

            return _solutionService.buildSolution(bestResult);
        }

        private void vaporisation(SolutionModel solution)
        {
            for (var i = 0; i < this._staffs.Count; i++)
            {
                for (var j = 0; j < this._orders.Count; j++)
                {
                    _pheromonesAssign[i][j] *= (1 - _conf.P);
                }
            }

            for (var j = 0; j < this._orders.Count; j++)
            {
                for (var j2 = 0; j2 <= this._orders.Count; j2++)
                {
                    _pheromonesSorting[j][j2] *= (1 - _conf.P);
                }
            }
        }

        private void update(SolutionModel solution)
        {
            var deltaT = _conf.P * _conf.DeltaT;
            for (var employeeIdx = 0; employeeIdx < this._staffs.Count; employeeIdx++)
            {
                var _idxLastJob = _orders.Count();
                foreach (var idxOrder in solution.Result[employeeIdx])
                {
                    _pheromonesAssign[employeeIdx][idxOrder] += deltaT;
                    _pheromonesSorting[idxOrder][_idxLastJob] += deltaT;
                    _idxLastJob = idxOrder;
                }
            }
        }

        private SolutionModel runOneAnt()
        {
           //bestimme job -> Mitarbeiter zuordnung
            var employeeJobAssignment = getEmployeeJobAssignment();

            //Reihenfolge in der Mitarbeiter Auftrag abarbeiten bestimmen
            var solution = sortEmployeeJobAssignment(employeeJobAssignment);

            //Console.WriteLine(solution.GetTotalCosts());

            return solution;
        }

        /*Reihenfolge in der Mitarbeiter Auftrag Abarbeiten*/
        private SolutionModel sortEmployeeJobAssignment(List<int>[] employeeJobAssignment)
        {
            var result = new List<int>[_staffs.Count];
            
            for (var i = 0; i < _staffs.Count; i++)
            {
                result[i] = new List<int>();
            }

            bool useMaxRule;

            for (var idxStaff = 0; idxStaff < _staffs.Count; idxStaff++)
            {
                var orders = employeeJobAssignment[idxStaff];
                var countJobs = _orders.Count;
                var IdxLastOrder = countJobs;
                while (orders.Count > 0)
                {
                    useMaxRule = (float)_random.NextDouble() <= _conf.Q;

                    var selectedOrderIdx = 0;

                    if (useMaxRule)
                    {
                        /*MAX(τijα * ηijβ)*/
                        float maxValue = 0;

                        foreach (var orderIdx in orders)
                        {
                            float heuristic;
                            if (IdxLastOrder == countJobs)
                            {
                                heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[orderIdx]);
                            }
                            else
                            {
                                heuristic = _solutionService.Heuristic.getValue(_orders[orderIdx], _orders[IdxLastOrder]);
                            }
                            var pheromon = _pheromonesSorting[orderIdx][IdxLastOrder];
                            var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));

                            if (value > maxValue)
                            {
                                maxValue = value;
                                selectedOrderIdx = orderIdx;
                            }
                        }
                    }
                    else {
                        float total = 0;
                        foreach (var orderIdx in orders)
                        {
                            float heuristic;
                            if (IdxLastOrder == countJobs)
                            {
                                heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[orderIdx]);
                            }
                            else
                            {
                                heuristic = _solutionService.Heuristic.getValue(_orders[orderIdx], _orders[IdxLastOrder]);
                            }
                            var pheromon = _pheromonesSorting[orderIdx][IdxLastOrder];
                            var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));

                            total += value;
                        }

                        var randomValue = _random.NextDouble() * total;
                        double currentValue = 0;


                        foreach (var orderIdx in orders)
                        {
                            float heuristic;
                            if (IdxLastOrder == countJobs)
                            {
                                heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[orderIdx]);
                            }
                            else
                            {
                                heuristic = _solutionService.Heuristic.getValue(_orders[orderIdx], _orders[IdxLastOrder]);
                            }
                            var pheromon = _pheromonesSorting[orderIdx][IdxLastOrder];
                            var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));

                            currentValue += value;
                            if (randomValue <= currentValue)
                            {
                                selectedOrderIdx = orderIdx;
                                break;
                            }
                        }
                    }

                    orders.Remove(selectedOrderIdx);
                    result[idxStaff].Add(selectedOrderIdx);
                    IdxLastOrder = selectedOrderIdx;
                }
            }

            return _solutionService.buildSolution(result);
        }

        /*welcher Mitarbeiter bearbeitet welchen Job*/
        private List<int>[] getEmployeeJobAssignment()
        {
            var employeeJobAssignment = new List<int>[_staffs.Count];
            for (var i = 0; i < _staffs.Count; i++)
            {
                employeeJobAssignment[i] = new List<int>();
            }

            BigInteger maxLoop = (BigInteger)_orders.Count * (BigInteger)_orders.Count;

            bool useMaxRule;

            for (var idxJob = 0; idxJob < _orders.Count; idxJob++)
            {
                if (maxLoop-- < 0)
                {
                    throw new Exception("Ant need to long");
                }

                useMaxRule = (float)_random.NextDouble() <= _conf.Q;

                if (useMaxRule)
                {
                    /*MAX(τijα * ηijβ)*/
                    float maxValue = 0;
                    int maxValueIdxStaff = 0;

                    for (var idxStaff = 0; idxStaff < _staffs.Count; idxStaff++)
                    {
                        if (!_solutionService.canStaffProcessOrder(idxStaff, idxJob))
                        {
                            continue;
                        }

                        var heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[idxJob]);
                        var pheromon = _pheromonesAssign[idxStaff][idxJob];
                        var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));

                        if (value > maxValue)
                        {
                            maxValue = value;
                            maxValueIdxStaff = idxStaff;
                        }
                    }

                    employeeJobAssignment[maxValueIdxStaff].Add(idxJob);
                }
                else
                {
                    /*Auswahl gewichteter Zufall BEGIN*/
                    float total = 0;

                    for (var idxStaff = 0; idxStaff < _staffs.Count; idxStaff++)
                    {
                        if (!_solutionService.canStaffProcessOrder(idxStaff, idxJob))
                        {
                            continue;
                        }

                        var heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[idxJob]);
                        var pheromon = _pheromonesAssign[idxStaff][idxJob];
                        var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));
                        total += value;
                    }

                    var randomValue = _random.NextDouble() * total;
                    double currentValue = 0;

                    for (var idxStaff = 0; idxStaff < _staffs.Count; idxStaff++)
                    {
                        if (!_solutionService.canStaffProcessOrder(idxStaff, idxJob))
                        {
                            continue;
                        }

                        var heuristic = _solutionService.Heuristic.getValue(_staffs[idxStaff], _orders[idxJob]);
                        var pheromon = _pheromonesAssign[idxStaff][idxJob];
                        var value = (float)(Math.Pow(pheromon, _conf.Alpha) * Math.Pow(heuristic, _conf.Beta));
                        currentValue += value;
                        if (randomValue <= currentValue)
                        {
                            employeeJobAssignment[idxStaff].Add(idxJob);
                            break;
                        }
                    }
                }
            }

            return employeeJobAssignment;
        }

        public void Dispose()
        {
            _pheromonesSorting = null;
            _pheromonesAssign = null;
            _bestSolution = null;
        }

        public List<object> GetPheromonMatrixs()
        {
            return new List<object>
            { _pheromonesAssign, _pheromonesSorting };
        }
    }
}
