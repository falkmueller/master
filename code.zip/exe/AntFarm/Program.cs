﻿using System;
using AntFarm.Algorithms;
using AntFarm.Services;
using AntFarm.Abstraction;
using AntFarm.Models;
using System.Collections.Generic;
using AntFarm.Heuristic;
using AntFarm.Measurement;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Linq;

namespace AntFarm
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("START");

            //testMessuring();

            //var m1 = new Parameter1Measurement();
            var m1 = new Alg1Measurement();
            m1.start();

            Console.WriteLine("END");
        }

        private static void testMessuring()
        {
            var Seeder = new Seeds();

            var algorithmConfiguration = new AlgorithmConfigurationModel(
                k: 100,
                ncMax: 20,
                t0: 1,
                p: 0.4f,
                deltaT: 1,
                alpha: 0.3f,
                beta: (1 - 0.3f),
                q: 0,
                qa: 0
            );

            var heuristic = new DistanceHeuristic(new GeoService()); // new TardinessHeuristic(); //
            var problem = Seeder.GetProblem(200, 3000, "test_1");

            var solutionService = new SolutionService(
                problem,
                algorithmConfiguration,
                new GeoService(),
                new PropertyService(),
                new CostsService(),
                heuristic
                );

            //double _latMin = 47.437836;
            //double _latMax = 54.939949;
            //double _lngMin = 5.909917;
            //double _lngMax = 15.180695;

            //Console.WriteLine((new GeoService().getDistance(new PointModel(_latMin, _lngMin), new PointModel(_latMax, _lngMax))).Distance);
            //return;

            //Console.WriteLine("Algorithmus 1: Greedy (Reference Algorithm)");
            //alg = new Algorithm1Greedy(solutionService);
            //writeSolutionLine(alg.Run().GetBestSolution());

            //runAlgorithm(new Algorithm1Random(solutionService), algorithmConfiguration);
            runAlgorithm(() => new Algorithm1Greedy(solutionService), solutionService);
            //runAlgorithm(new Algorithm2Simple(solutionService), algorithmConfiguration);
            //runAlgorithm(() => new Algorithm3(solutionService), solutionService);
            //runAlgorithm(() => new Algorithm4(solutionService), solutionService);
            runAlgorithm(() => new Algorithm5(solutionService), solutionService);
            //runAlgorithm(() => new Algorithm6(solutionService), solutionService);
        }


        private static void runAlgorithm(Func<IAlgorithm> algGenerator, SolutionService solutionService)
        {
            var alg = algGenerator();
            Console.WriteLine("{0}", alg.GetType().Name);
           
            var costsPerIteration = new List<object>();
            var iteration = 0;
            for (var i = 0; i < solutionService.AlgorithmConfiguration.NcMax; i++)
            {
                var tempResult = alg.Run().GetBestSolution();
               
                costsPerIteration.Add(new
                {
                    Iteration = iteration,
                    tempResult.Distance,
                    tempResult.TardinessCosts,
                    tempResult.StuffOrderCosts,
                    tempResult.StaffTravelCosts,
                    tempResult.PropertyInaptitude,
                    total = tempResult.GetTotalCosts()
                });

                writeSolutionLine(tempResult);
                iteration++;
            }
        }
 

        private static void writeSolutionLine(SolutionModel solutionModel)
        {
            Console.WriteLine(
                        "{0:n}\tD:{1:n}\tT:{2:n}\t{3:n}\t{4:n}\t{5:n}",
                        (Int64)solutionModel?.GetTotalCosts(),
                        (Int64)solutionModel?.Distance,
                        (Int64)solutionModel?.TardinessCosts,
                        (Int64)solutionModel?.StaffTravelCosts,
                        (Int64)solutionModel?.StuffOrderCosts,
                        (Int64)(solutionModel?.PropertyInaptitude));
        }
    }
}
