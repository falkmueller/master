﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Models;

namespace AntFarm.Services
{
    public class PropertyService
    {
        public bool canStaffProcessOrder(StaffModel staff, OrderModel order)
        {
            foreach (var prop in order.ObligatoryStaffProperties)
            {
                if (!Array.Exists(staff.Properties, element => element.Equals(prop)))
                {
                    return false;
                }
            }

            return true;
        }

        public float getStaffOrderPreference(StaffModel staff, OrderModel order)
        {
            var fullfilledPropetiesCount = 0;
            
            foreach (var prop in order.ObligatoryStaffProperties)
            {
                if (Array.Exists(staff.Properties, element => element.Equals(prop)))
                {
                    fullfilledPropetiesCount++;
                }
            }

            foreach (var prop in order.OptionalStaffProperties)
            {
                if (Array.Exists(staff.Properties, element => element.Equals(prop)))
                {
                    fullfilledPropetiesCount++;
                }
            }

            var totalPropertiesCount = order.ObligatoryStaffProperties.Length + order.OptionalStaffProperties.Length;

            if (totalPropertiesCount == 0)
            {
                return 0.5F;
            }

            return fullfilledPropetiesCount / totalPropertiesCount;
        }
    }
}