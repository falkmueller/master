﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Models;
using System.Linq;
using AntFarm.Abstraction;

namespace AntFarm.Services
{
    public class SolutionService
    {
        private GeoService _geoService;
        private PropertyService _propertyService;
        private CostsService _costsService;

        public ProblemModel Problem { protected set; get; }
        public AlgorithmConfigurationModel AlgorithmConfiguration { protected set; get; }
        public IHeuristic Heuristic { protected set; get; }

        private bool?[][] _canStaffProcessOrderCache;

        public SolutionService(
            ProblemModel problem,
            AlgorithmConfigurationModel algorithmConfiguration,
            GeoService geoService, 
            PropertyService propertyService, 
            CostsService costsService,
            IHeuristic heuristic)
        {
            _geoService = geoService;
            _propertyService = propertyService;
            _costsService = costsService;
            Problem = problem;
            AlgorithmConfiguration = algorithmConfiguration;
            Heuristic = heuristic;

            _canStaffProcessOrderCache = new bool?[Problem.Staffs.Count][];
            for (var staffId = 0; staffId < Problem.Staffs.Count; staffId++)
            {
                _canStaffProcessOrderCache[staffId] = new bool?[Problem.Orders.Count];

                for (var orderId = 0; orderId < Problem.Orders.Count; orderId++)
                {
                    _canStaffProcessOrderCache[staffId][orderId] = _propertyService.canStaffProcessOrder(Problem.Staffs[staffId], Problem.Orders[orderId]);
                }  
            }
        }

        public SolutionModel buildSolution(List<int>[] result)
        {
            double distance = 0;
            double staffOrderPreference = 0;
            Int64 tardinessCosts = 0;
            Int64 stuffOrderCosts = 0;
            Int64 staffTravelCosts = 0;

            for (var idxStaff = 0; idxStaff < Problem.Staffs.Count; idxStaff++)
            {
                var staff = Problem.Staffs[idxStaff];
                var lastPositionOfStaff = staff.Point;
                float time = 0;

                foreach (var orderIdx in result[idxStaff])
                {
                    var order = Problem.Orders[orderIdx];

                    //mesure distance (aktuell annahme das adm nur eine tour brauch für alle Aufträge)
                    var travel = _geoService.getDistance(
                                lastPositionOfStaff,
                               order.Point
                                );
                    distance += travel.Distance;

                    lastPositionOfStaff = order.Point;

                    //build preference
                    staffOrderPreference += _propertyService.getStaffOrderPreference(staff, order);

                    //build costs
                    staffTravelCosts += _costsService.getStaffTravelCosts(travel, staff);
                    stuffOrderCosts += _costsService.getStuffOrderCosts(order, staff);
                    tardinessCosts += _costsService.GetTardinessCosts(order, time);

                    time += travel.DurationInHours + order.DurationInHours;
                }
            }

            return new SolutionModel(
                result,
                distance,
                Problem.Orders.Count - staffOrderPreference,
                tardinessCosts,
                stuffOrderCosts,
                staffTravelCosts
                );
        }

        public bool canStaffProcessOrder(int staffId, int orderId) {
            return _canStaffProcessOrderCache[staffId][orderId] ?? false;
        }
    }
}
