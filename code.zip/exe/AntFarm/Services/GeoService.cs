﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Models;

namespace AntFarm.Services
{
    public class GeoService
    {

        public RoutingResultModel getDistance(PointModel startPoint, PointModel endPoint)
        {
            //calculate simple distance in km
            //dist = 6378.388 * acos(sin(lat1) * sin(lat2) + cos(lat1) * cos(lat2) * cos(lon2 - lon1))
            //source: https://www.kompf.de/gps/distcalc.html
            //var distance = 111.324 * Math.Acos(
            //    Math.Sin(startPoint.Lat) * Math.Sin(endPoint.Lat) +
            //    Math.Cos(startPoint.Lat) * Math.Cos(endPoint.Lat) * Math.Cos(endPoint.Lng - startPoint.Lng)
            //    );

            //the original code from .NET-Frameworks GeoCoordinate class
            var d1 = startPoint.Lat * (Math.PI / 180.0);
            var num1 = startPoint.Lng * (Math.PI / 180.0);
            var d2 = endPoint.Lat * (Math.PI / 180.0);
            var num2 = endPoint.Lng * (Math.PI / 180.0) - num1;
            var d3 = Math.Pow(Math.Sin((d2 - d1) / 2.0), 2.0) + Math.Cos(d1) * Math.Cos(d2) * Math.Pow(Math.Sin(num2 / 2.0), 2.0);

            var distance = Constants.EarthRadius * (2.0 * Math.Atan2(Math.Sqrt(d3), Math.Sqrt(1.0 - d3)));

            return new RoutingResultModel
            {
                Distance = (float)distance,
                DurationInHours = (float)(distance * Constants.HoursProKm)
            };
        }
    }
}
