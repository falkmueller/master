﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Models;

namespace AntFarm.Services
{
    public class CostsService
    {
        public Int64 GetTardinessCosts(OrderModel order, float startTime)
        {
            var timeDiffInHour = startTime -  order.Duedate;
            return Math.Max((Int64)(order.TardinessCostsPerHour * (timeDiffInHour + order.DurationInHours)), 0);
        }

        public Int64 getStuffOrderCosts(OrderModel order, StaffModel staff)
        {
            return (Int64)(order.DurationInHours * staff.CostPerHoure);
        }

        public Int64 getStaffTravelCosts(RoutingResultModel routingResult, StaffModel staff)
        {
            return (Int64)(routingResult.DurationInHours * staff.CostPerHoure);
        }
    }
}
