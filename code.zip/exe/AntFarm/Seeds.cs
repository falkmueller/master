﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Models;
using System.Text.Json;
using System.IO;
using System.Reflection;

namespace AntFarm
{
    class Seeds
    {
        private double _latMin = 47.437836;
        private double _latMax = 54.939949;
        private double _lngMin = 5.909917;
        private double _lngMax = 15.180695;
        private int _StaffCostPerHoureMin = 10;
        private int _StaffCostPerHoureMax = 20;
        private int _OrderDurationInHoursMin = 6;
        private int _OrderDurationInHoursMax = 16;
        private int _TardinessCostsPerHourMin = 100;
        private int _TardinessCostsPerHourMax = 1000;

        private Random _random;
        private int _staffCount;
        private int _ordersCount;

        /*
         * Zeitspanne in der die AUfträge liegen
         * {Etwas weniger als die Durchschnittliche bearbeitungszeit für einen Auftrag} * {Anzahl Aufträge}
         * Fahrtzeiten sind nicht berücksichtigt, dadurch wird es also zu Verspätungskosten kommen müssen
         */
        private int _maxDueDate 
        { 
            get 
            { 
                return (_OrderDurationInHoursMax - _OrderDurationInHoursMin) * _ordersCount; 
            } 
        }

        /*
         * Eigenschaften und deren Verteilung auf die Mitarbeiten
         */
        private Dictionary<string, float> _staffProperties = new Dictionary<string, float> {
            { "A", 0.5F }, { "B", 0.5F }, { "C", 0.5F }, { "D", 0.5F }, { "E", 0.5F }, { "F", 0.5F }, { "Ob1", 0.5F }, { "Ob2", 0.5F }
        };

        private Dictionary<string, float> _orderOptionalStaffProperties = new Dictionary<string, float> {
            { "A", 0.5F }, { "B", 0.5F }, { "C", 0.5F }, { "D", 0.5F }, { "E", 0.5F }, { "F", 0.5F }
        };

        private Dictionary<string, float> _orderObligatoryStaffProperties = new Dictionary<string, float> {
            { "Ob1", 0.5F }, { "Ob2", 0.5F }
        };

        public Seeds() {
            _random = new Random();
        }


        private PointModel getRandomPoint()
        {
            return new PointModel(
                _latMin + (_random.NextDouble() * (_latMax - _latMin)),
                _lngMin + (_random.NextDouble() * (_lngMax - _lngMin))
                );
        }

        public ProblemModel GetProblem(int staffCount, int ordersCount)
        {
            return GetProblem(staffCount, ordersCount, string.Empty);
        }

        public ProblemModel GetProblem(int staffCount, int ordersCount, string name)
        {
            _staffCount = staffCount;
            _ordersCount = ordersCount;

            if (!string.IsNullOrWhiteSpace(name))
            {
                /*load, if exists*/
                var path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "seeds", $"{ProblemModel.GetUniqueName(_staffCount,_ordersCount, name)}.json");
                if (File.Exists(path)) {
                    var jsonString = File.ReadAllText(path);
                    return Newtonsoft.Json.JsonConvert.DeserializeObject<ProblemModel>(jsonString);
                }
            }

            var problem = new ProblemModel(getStaff(), getOrders(), name);

            if (!string.IsNullOrWhiteSpace(name))
            {
                /*store*/
                var path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "seeds", $"{problem.GetUniqueName()}.json");
                var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(problem, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(path, jsonString);
            }

            return problem;
        }

        private List<StaffModel> getStaff()
        {
            var staffList = new List<StaffModel>();

            for (var i = 0; i < _staffCount; i++) 
            {
                var properties = new List<string>();

                foreach (var prop in _staffProperties)
                {
                    if (_random.NextDouble() <= prop.Value){
                        properties.Add(prop.Key);
                    }
                }

                staffList.Add(
                    new StaffModel
                    { 
                        Point = getRandomPoint(),
                        CostPerHoure = _StaffCostPerHoureMin + (int)(_random.NextDouble() * (_StaffCostPerHoureMax - _StaffCostPerHoureMin)),
                        Properties = properties.ToArray()
                    }
                    );
            }

            return staffList;
        }

        private List<OrderModel> getOrders()
        {
            var orderList = new List<OrderModel>();


            for (var i = 0; i < _ordersCount; i++)
            {
                var obligatoryStaffProperties = new List<string>();

                foreach (var prop in _orderObligatoryStaffProperties)
                {
                    if (_random.NextDouble() <= prop.Value)
                    {
                        obligatoryStaffProperties.Add(prop.Key);
                    }
                }

                var optionalStaffProperties = new List<string>();

                foreach (var prop in _orderOptionalStaffProperties)
                {
                    if (_random.NextDouble() <= prop.Value)
                    {
                        optionalStaffProperties.Add(prop.Key);
                    }
                }

                orderList.Add(
                    new OrderModel
                    {
                        Point = getRandomPoint(),
                        DurationInHours = _OrderDurationInHoursMin + (int)(_random.NextDouble() * (_OrderDurationInHoursMax - _OrderDurationInHoursMin)),
                        TardinessCostsPerHour = _TardinessCostsPerHourMin + (int)(_random.NextDouble() * (_TardinessCostsPerHourMax - _TardinessCostsPerHourMin)),
                        Duedate = (int)(_random.NextDouble() * _maxDueDate),
                        ObligatoryStaffProperties = obligatoryStaffProperties.ToArray(),
                        OptionalStaffProperties = optionalStaffProperties.ToArray()
                    }
                    );
            }

            return orderList;
        }
    }
}
