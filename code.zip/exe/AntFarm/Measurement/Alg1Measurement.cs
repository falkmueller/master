﻿using System;
using AntFarm.Algorithms;
using AntFarm.Services;
using AntFarm.Abstraction;
using AntFarm.Models;
using System.Collections.Generic;
using AntFarm.Heuristic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
namespace AntFarm.Measurement
{
    public class Alg1Measurement
    {
        private readonly string _path;
        private readonly AlgorithmConfigurationModel _algorithmConfiguration;
        private readonly IHeuristic _heuristic;
        private readonly ProblemModel _problem;
        private readonly bool _plotIteration = false;
        private Random _random;

        public Alg1Measurement()
        {
            _random = new Random();
            _path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), this.GetType().Name, DateTime.Now.ToString("yyyMMddHHmmss"));
            Directory.CreateDirectory(_path);

            _algorithmConfiguration = new AlgorithmConfigurationModel
                            (
                                alpha: 0.1f,
                                beta: 1 - 0.1f,
                                deltaT: 1,
                                t0: 1,
                                k: 30,
                                p: 0.7f,
                                ncMax: 80,
                                q: 0.6f,
                                qa: 0
                            )
            {
                T = 0.003f
            };

            _heuristic = new DistanceHeuristic(new GeoService());
            var Seeder = new Seeds();
            _problem = Seeder.GetProblem(200, 3000, "messurement_4");
        }

        public void start()
        {
      
            var solutionService = new SolutionService(
                _problem,
                _algorithmConfiguration,
                new GeoService(),
                new PropertyService(),
                new CostsService(),
                _heuristic
                );

            var algs = new List<Type> { typeof(Algorithm6) /*typeof(Algorithm6) , typeof(Algorithm5),  typeof(Algorithm4)*/ };

            //for (var i = 0; i < 10; i++)
            //{
            foreach (var algType in algs)
            {
                //var name = $"{nameof(algType)}_{i}_{solutionService.Problem.GetUniqueName()}_{solutionService.AlgorithmConfiguration.GetUniqueName()}";
                var name = $"{algType.Name}_{solutionService.Problem.GetUniqueName()}_{solutionService.AlgorithmConfiguration.GetUniqueName()}_{_random.Next()}";
                var path = Path.Combine(_path, $"{name}");
                Directory.CreateDirectory(path);
                runAlgorithm(() => (IAlgorithm)Activator.CreateInstance(algType, new object[] { solutionService }), path, solutionService);
            }
            ////}
       
        }

        private void runAlgorithm(Func<IAlgorithm> algGenerator, string path, SolutionService solutionService)
        {
            var phermonPlottings = new Dictionary<int, int>
            {
                { 5, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.05m )},
                { 10, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.1m )},
                { 20, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.2m )},
                { 40, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.4m)},
                { 60, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.6m)},
                { 80, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.8m)},
                { 100, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax)}
            };

            var stopwatch = Stopwatch.StartNew();
            var startMemoryUsage = Process.GetCurrentProcess().PrivateMemorySize64;
            long memoryUsage;

            var alg = algGenerator();
            var costsPerIteration = new List<object>();
            for (var iteration = 0; iteration < solutionService.AlgorithmConfiguration.NcMax; iteration++)
            {
                var tempResult = alg.Run().GetBestSolution();
                Console.WriteLine("{0} {1} {2}", iteration, solutionService.AlgorithmConfiguration.K, tempResult.GetTotalCosts());

                costsPerIteration.Add(new
                {
                    Iteration = iteration,
                    tempResult.Distance,
                    tempResult.TardinessCosts,
                    tempResult.StuffOrderCosts,
                    tempResult.StaffTravelCosts,
                    tempResult.PropertyInaptitude,
                    total = tempResult.GetTotalCosts()
                });

                //if(iteration % 5 == 0 || iteration + 1 == solutionService.AlgorithmConfiguration.NcMax)
                //{
                //    File.WriteAllText(
                //        Path.Combine(path, $"result_{iteration}.json"),
                //        Newtonsoft.Json.JsonConvert.SerializeObject(tempResult.Result, Newtonsoft.Json.Formatting.Indented)
                //    );
                //}


                var plotIteration = phermonPlottings.Where(p => p.Value == iteration + 1);
                if (_plotIteration && plotIteration.Any())
                {
                    var percent = plotIteration.First().Key;
                    var pheromones = alg.GetPheromonMatrixs();
                    if (pheromones != null)
                    {
                        for (var pi = 0; pi < pheromones.Count; pi++)
                        {
                            File.WriteAllText(
                                Path.Combine(path, $"pheromon_{percent}_{pi}.json"),
                                Newtonsoft.Json.JsonConvert.SerializeObject(pheromones[pi], Newtonsoft.Json.Formatting.Indented)
                            );
                        }
                    }
                }


            }

            memoryUsage = Process.GetCurrentProcess().PrivateMemorySize64;
            var result = alg.Run().GetBestSolution();

            stopwatch.Stop();

            File.WriteAllText(
               Path.Combine(path, "run.json"),
               Newtonsoft.Json.JsonConvert.SerializeObject(new
               {
                   Algorithmus = alg.GetType().Name,
                   Heuristic = solutionService.Heuristic.GetType().Name,
                   Parameter = solutionService.AlgorithmConfiguration,
                   Problem = new { Name = solutionService.Problem.GetUniqueName(), CountStaff = solutionService.Problem.Staffs.Count, CountOrders = solutionService.Problem.Orders.Count },
                   usage = new { cpuTime = stopwatch.ElapsedMilliseconds, memoryUsage = (float)(memoryUsage - startMemoryUsage) / 1024 / 1024 },
                   costs = new
                   {
                       result.Distance,
                       result.TardinessCosts,
                       result.StuffOrderCosts,
                       result.StaffTravelCosts,
                       result.PropertyInaptitude,
                       total = result.GetTotalCosts()
                   }
               }, Newtonsoft.Json.Formatting.Indented)
           );

            File.WriteAllText(
               Path.Combine(path, "result.json"),
               Newtonsoft.Json.JsonConvert.SerializeObject(result.Result, Newtonsoft.Json.Formatting.Indented)
           );

            File.WriteAllText(
               Path.Combine(path, "costs.json"),
               Newtonsoft.Json.JsonConvert.SerializeObject(costsPerIteration, Newtonsoft.Json.Formatting.Indented)
           );

            alg.Dispose();


        }
    }
}
