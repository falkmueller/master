﻿using System;
using AntFarm.Algorithms;
using AntFarm.Services;
using AntFarm.Abstraction;
using AntFarm.Models;
using System.Collections.Generic;
using AntFarm.Heuristic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AntFarm.Measurement
{
    class Parameter1Measurement
    {
        private readonly string _path;
        private readonly List<AlgorithmConfigurationModel> _algorithmConfigurations;
        private readonly IHeuristic _heuristic;
        private readonly ProblemModel _problem;
        private readonly bool _plotIteration = false;

        public Parameter1Measurement()
        {
            _path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), this.GetType().Name, DateTime.Now.ToString("yyyMMddHHmmss"));
            Directory.CreateDirectory(_path);

            var ks = new List<int> { 30/*, 30, 40, 50, 60, 70*/ };
            var ps = new List<float> {/*0.3f, 0.4f, 0.5f,*/ 0.7f/*, 0.7f, 0.8f*/ };
            var aas = new List<float> { 0.1f /* 0.2f, 0.3f, 0.4f*/};
            //var qs = new List<float> { 0, 0.05f, 0.1f, 0.2f, 0.3f };
            var qs = new List<float> { 0.6f};

            _algorithmConfigurations = new List<AlgorithmConfigurationModel>();
            foreach (var k in ks)
            {
                foreach (var p in ps)
                {
                    foreach (var a in aas)
                    {
                        foreach (var q in qs)
                        {
                                _algorithmConfigurations.Add(new AlgorithmConfigurationModel
                                (
                                    alpha: a,
                                    beta: 1 - a,
                                    deltaT: 1,
                                    t0: 1,
                                    k: k,
                                    p: p,
                                    ncMax: 100,
                                    q: q,
                                    qa: 0
                                ));
                        }
                    }
                }
            }

            _heuristic = new DistanceHeuristic(new GeoService());
            var Seeder = new Seeds();
            _problem = Seeder.GetProblem(200, 3000, "messurement_4");
        }

        public void start()
        {
            foreach (var algorithmConfiguration in _algorithmConfigurations)
            {
                var solutionService = new SolutionService(
                    _problem,
                    algorithmConfiguration,
                    new GeoService(),
                    new PropertyService(),
                    new CostsService(),
                    _heuristic
                    );

                //Thread[] objThread = new Thread[5];

                for (var i = 0; i < 3; i++)
                {
                    var name = $"{i}_{nameof(Algorithm5)}_{solutionService.Problem.GetUniqueName()}_{solutionService.AlgorithmConfiguration.GetUniqueName()}";
                    var path = Path.Combine(_path, $"{name}");
                    Directory.CreateDirectory(path);

                    runAlgorithm(() => new Algorithm6(solutionService), path, solutionService);

                    //objThread[i] = new Thread(() => runAlgorithm(() => new Algorithm5(solutionService), path, solutionService));
                    //objThread[i].Priority = ThreadPriority.AboveNormal;
                    //objThread[i].Start();
                }

                //for (int i = 0; i < objThread.Length; i++)
                //{
                //    // Wait until thread is finished.
                //    objThread[i].Join();
                //}
                Console.WriteLine("Finish Thread loop");
            }
        }

        private void runAlgorithm(Func<IAlgorithm> algGenerator, string path, SolutionService solutionService)
        {
            var phermonPlottings = new Dictionary<int, int>
            {
                { 5, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.05m )},
                { 10, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.1m )},
                { 20, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.2m )},
                { 40, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.4m)},
                { 60, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.6m)},
                { 80, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax * 0.8m)},
                { 100, (int)Math.Ceiling((decimal)solutionService.AlgorithmConfiguration.NcMax)}
            };

            var stopwatch = Stopwatch.StartNew();
            var startMemoryUsage = Process.GetCurrentProcess().PrivateMemorySize64;
            long memoryUsage;

            var alg = algGenerator();
            var costsPerIteration = new List<object>();
            for (var iteration = 0; iteration < solutionService.AlgorithmConfiguration.NcMax; iteration++)
            {
                var tempResult = alg.Run().GetBestSolution();
                Console.WriteLine("{0} {1} {2}", iteration, solutionService.AlgorithmConfiguration.K, tempResult.GetTotalCosts());

                costsPerIteration.Add(new
                {
                    Iteration = iteration,
                    tempResult.Distance,
                    tempResult.TardinessCosts,
                    tempResult.StuffOrderCosts,
                    tempResult.StaffTravelCosts,
                    tempResult.PropertyInaptitude,
                    total = tempResult.GetTotalCosts()
                });

                var plotIteration = phermonPlottings.Where(p => p.Value == iteration + 1);
                if (_plotIteration && plotIteration.Any())
                {
                    var percent = plotIteration.First().Key;
                    var pheromones = alg.GetPheromonMatrixs();
                    if (pheromones != null)
                    {
                        for (var pi = 0; pi < pheromones.Count; pi++)
                        {
                            File.WriteAllText(
                                Path.Combine(path, $"pheromon_{percent}_{pi}.json"),
                                Newtonsoft.Json.JsonConvert.SerializeObject(pheromones[pi], Newtonsoft.Json.Formatting.Indented)
                            );
                        }
                    }
                }

                
            }

            memoryUsage = Process.GetCurrentProcess().PrivateMemorySize64;
            var result = alg.Run().GetBestSolution();

            stopwatch.Stop();

            File.WriteAllText(
               Path.Combine(path, "run.json"),
               Newtonsoft.Json.JsonConvert.SerializeObject(new
               {
                   Algorithmus = alg.GetType().Name,
                   Heuristic = solutionService.Heuristic.GetType().Name,
                   Parameter = solutionService.AlgorithmConfiguration,
                   Problem = new { Name = solutionService.Problem.GetUniqueName(), CountStaff = solutionService.Problem.Staffs.Count, CountOrders = solutionService.Problem.Orders.Count },
                   usage = new { cpuTime = stopwatch.ElapsedMilliseconds, memoryUsage = (float)(memoryUsage - startMemoryUsage) / 1024 / 1024 },
                   costs = new
                   {
                       result.Distance,
                       result.TardinessCosts,
                       result.StuffOrderCosts,
                       result.StaffTravelCosts,
                       result.PropertyInaptitude,
                       total = result.GetTotalCosts()
                   }
               }, Newtonsoft.Json.Formatting.Indented)
           );

            File.WriteAllText(
               Path.Combine(path, "result.json"),
               Newtonsoft.Json.JsonConvert.SerializeObject(result.Result, Newtonsoft.Json.Formatting.Indented)
           );

            File.WriteAllText(
               Path.Combine(path, "costs.json"),
               Newtonsoft.Json.JsonConvert.SerializeObject(costsPerIteration, Newtonsoft.Json.Formatting.Indented)
           );

            alg.Dispose();


        }
    }
}
