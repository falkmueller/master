﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AntFarm
{
    public static class Constants
    {
        public static double EarthRadius { get; set; } = 6378.388;
        public static double HoursProKm { get; set; } = 0.02;
    }
}
