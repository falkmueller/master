﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Abstraction;
using AntFarm.Models;
using AntFarm.Services;

namespace AntFarm.Heuristic
{
    class TardinessHeuristic : IHeuristic
    {

        public TardinessHeuristic()
        { }

        public float getValue(StaffModel staff, OrderModel order)
        {
            return 1 / order.Duedate;
        }

        public float getValue(OrderModel order, OrderModel prevOrder)
        {
            return 1 / order.Duedate -  1 / prevOrder.Duedate;
        }
    }
}
