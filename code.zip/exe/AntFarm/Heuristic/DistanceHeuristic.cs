﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Abstraction;
using AntFarm.Models;
using AntFarm.Services;

namespace AntFarm.Heuristic
{
    public class DistanceHeuristic : IHeuristic
    {
        private GeoService _geoService;

        public DistanceHeuristic(GeoService geoService)
        {
            _geoService = geoService;
        }

        public float getValue(StaffModel staff, OrderModel order)
        {
            return 1 / getDistance(staff.Point, order.Point);
        }

        public float getValue(OrderModel prevOrder, OrderModel nextOrder)
        {
            return 1 / getDistance(prevOrder.Point, nextOrder.Point);
        }

        private float getDistance(PointModel startPoint, PointModel endPoint)
        {
            return _geoService.getDistance(startPoint, endPoint).Distance;
        }
    }
}
