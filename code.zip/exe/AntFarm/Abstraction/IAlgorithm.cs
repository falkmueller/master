﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Models;

namespace AntFarm.Abstraction
{
    public interface IAlgorithm : IDisposable
    {
        IAlgorithm Run();
        SolutionModel GetBestSolution();

        List<object> GetPheromonMatrixs();
    }
}
