﻿using System;
using System.Collections.Generic;
using System.Text;
using AntFarm.Models;

namespace AntFarm.Abstraction
{
    public interface IHeuristic
    {
        float getValue(StaffModel staff, OrderModel order);
        float getValue(OrderModel prevOrder, OrderModel nextOrder);
    }
}
